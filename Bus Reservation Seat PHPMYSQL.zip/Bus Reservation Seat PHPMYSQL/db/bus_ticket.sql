-- phpMyAdmin SQL Dump
-- version 4.4.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 07, 2017 at 01:08 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bus_ticket`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(25) NOT NULL,
  `name` varchar(30) NOT NULL,
  `uname` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `type` varchar(25) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `uname`, `password`, `type`) VALUES
(1, 'admin', 'admin', 'admin', '');

-- --------------------------------------------------------

--
-- Table structure for table `bus`
--

CREATE TABLE IF NOT EXISTS `bus` (
  `bid` varchar(11) NOT NULL,
  `bname` varchar(50) NOT NULL,
  `type_ac` char(3) NOT NULL,
  `type_sl` char(3) NOT NULL,
  `busdriver` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bus`
--

INSERT INTO `bus` (`bid`, `bname`, `type_ac`, `type_sl`, `busdriver`) VALUES
('BB001', 'Ganga', 'yes', 'yes', 'Kevin'),
('BB002', 'SRS Travels', 'no', 'yes', 'Sila'),
('BB003', 'VOLVO', 'yes', 'yes', 'Morio'),
('BB004', 'Sugama', 'no', 'yes', 'Kamatia'),
('BB005', 'KALYANA', 'no', 'yes', 'Chini'),
('BB006', 'Durgamba', 'no', 'yes', 'Wacha'),
('BB007', 'SLV', 'no', 'yes', 'Sisi'),
('BB008', 'KKB', 'no', 'yes', 'Kisu'),
('BB009', 'TCS', 'no', 'yes', 'Mwewe'),
('BB010', 'Jain Travels', 'no', 'yes', 'Kitungu'),
('BB011', 'VRV', 'no', 'yes', 'Ndania'),
('BB012', 'SRA', 'no', 'yes', 'Brian'),
('BB013', 'VRX', 'no', 'yes', 'Wendy'),
('BB014', 'Gene', 'no', 'yes', 'Sasa'),
('BB015', 'GT', 'yes', 'no', 'Kitusuru'),
('BB016', 'Vani', 'no', 'yes', 'Cocacola'),
('BB017', 'GRS', 'no', 'yes', 'Aswani'),
('BB018', 'VYT', 'yes', 'no', 'Solo'),
('BB019', 'RTT', 'yes', 'no', 'Martin'),
('BB020', 'BTE', 'yes', 'no', 'Allan'),
('BB021', 'Rose', 'yes', 'no', 'Cate'),
('BB022', 'VRDT', 'yes', 'no', 'Tecla'),
('BB023', 'Vellore Travels', 'yes', 'no', 'Tekila'),
('BB024', 'Vamanur Travels', 'yes', 'no', 'Glass'),
('BB025', 'Varada Travels', 'yes', 'no', ''),
('BB026', 'Narmada Travels', 'yes', 'no', ''),
('BB027', 'VYT', 'yes', 'no', ''),
('BB028', 'KKB Express', 'no', 'yes', ''),
('BB029', 'PK', 'no', 'yes', ''),
('BB030', 'Jain Travels', 'no', 'yes', ''),
('BB031', 'Vardhaman Travels', 'no', 'no', ''),
('BB032', 'Vaikunta Travels', 'no', 'no', ''),
('BB033', 'Tirupati Travels', 'no', 'no', ''),
('BB034', 'Jain Travels', 'no', 'no', ''),
('BB035', 'Vamanahalli Travels', 'no', 'no', ''),
('BB036', 'Janata  Travels', 'no', 'no', ''),
('BB037', 'Janata Express', 'no', 'no', ''),
('BB038', 'vadra Travels', 'no', 'no', '');

-- --------------------------------------------------------

--
-- Table structure for table `card`
--

CREATE TABLE IF NOT EXISTS `card` (
  `num` varchar(16) NOT NULL,
  `type` varchar(30) NOT NULL,
  `expdate` date NOT NULL,
  `cvv` int(11) NOT NULL,
  `bank` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `card`
--

INSERT INTO `card` (`num`, `type`, `expdate`, `cvv`, `bank`) VALUES
('12345', 'VISA', '2017-11-01', 333, 'CitiBank');

-- --------------------------------------------------------

--
-- Table structure for table `nb`
--

CREATE TABLE IF NOT EXISTS `nb` (
  `uname` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `bank` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nb`
--

INSERT INTO `nb` (`uname`, `password`, `bank`) VALUES
('Kevin', '1234', 'CitiBank');

-- --------------------------------------------------------

--
-- Table structure for table `passenger`
--

CREATE TABLE IF NOT EXISTS `passenger` (
  `pid` varchar(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mob` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `passenger`
--

INSERT INTO `passenger` (`pid`, `name`, `email`, `mob`) VALUES
('1111111', 'Admin', 'admin@starbus.com', '1234567890'),
('1111112', 'Susan', 'sasan45@gmail.com', '8867159511'),
('1111113', 'Collo', 'Collo5@gmail.com', '8867159511'),
('1111114', 'Joyce', 'joyce@gmail.com', '8867159511'),
('1111115', 'Kevin', 'niketraj45@gmail.com', '8867159511'),
('1111116', 'Kevin', 'kevin@gmail.com', '1234567890'),
('1111117', 'Kevin', 'susan@gmail.com', '8867159511'),
('1111118', 'Kevin', 'kevin@gmail.com', '12345'),
('1111119', 'Ssa', 'ssaj45@gmail.com', '8867159511'),
('1111120', 'Kwaiu', 'kwaitu@gmail.com', '8867159511'),
('1111121', 'Brenda', 'brenda@gmail.com', '0886715951'),
('1111122', 'Sssawa', 'ssawale@gmail.com', '0886715951'),
('1111123', 'kaka mjanja', 'kaka@gmail.com', '12345'),
('1111124', 'kaka mjanja', 'kaka@gmail.com', '12345'),
('1111125', 'kaka mjanja', 'kaka@gmail.com', '12345'),
('1111126', 'kaka mjanja', 'kaka@gmail.com', '12345'),
('1111127', 'kaka mjanja', 'kaka@gmail.com', '12345'),
('1111128', 'kaka mjanja', 'kaka@gmail.com', '12345'),
('1111129', 'kaka mjanja', 'kaka@gmail.com', '12345'),
('1111130', 'kaka mjanja', 'kaka@gmail.com', '12345'),
('1111131', 'kaka mjanja', 'kaka@gmail.com', '12345'),
('1111132', 'ssss', 'kaka@gmail.com', '12345'),
('1111133', 'ssss', 'kaka@gmail.com', '12345'),
('1111134', 'Kevo', 'kevo@gmail.com', '123456'),
('1111135', 'ninja', 'ninja@gmail.com', '12345'),
('1111136', 'ssss', 'sss@gmail.com', '12345'),
('1111137', 'ssss', 'sss@gmail.com', '12345'),
('1111138', 'sasa', 'kakasasa@gmail.com', '12345'),
('1111139', 'kakasasa', 'kaksasa@gmail.com', '12345'),
('1111140', 'kakasasa', 'kaksasa@gmail.com', '12345'),
('1111141', 'kakasasa', 'kaksasa@gmail.com', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `reserves`
--

CREATE TABLE IF NOT EXISTS `reserves` (
  `pnr` int(11) NOT NULL,
  `rid` int(11) DEFAULT NULL,
  `pid` varchar(11) DEFAULT NULL,
  `status` varchar(11) DEFAULT NULL,
  `DOT` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reserves`
--

INSERT INTO `reserves` (`pnr`, `rid`, `pid`, `status`, `DOT`) VALUES
(22, 10001, '1111116', 'booked', '2017-07-04 09:29:09'),
(23, 10001, '1111116', 'booked', '2017-07-05 09:29:09'),
(24, 10000, '1111117', 'cancelled', '2017-07-06 09:29:09'),
(25, 10000, '1111117', 'cancelled', '2017-07-07 09:29:09'),
(26, 10001, '1111118', 'booked', '2017-07-08 09:29:09'),
(27, 10001, '1111118', 'booked', '2017-07-09 09:29:09'),
(28, 10001, '1111118', 'booked', '2017-07-10 09:29:09'),
(29, 10000, '1111120', 'cancelled', '2017-07-11 09:29:09'),
(30, 10000, '1111120', 'cancelled', '2017-07-12 09:29:09'),
(31, 10000, '1111120', 'cancelled', '2017-07-13 09:29:09'),
(32, 10000, '1111121', 'booked', '2017-07-14 09:29:09'),
(33, 10000, '1111121', 'booked', '2017-07-04 09:29:09'),
(34, 10000, '1111121', 'booked', '2015-09-30 12:40:21'),
(35, 10000, '1111133', 'cancelled', '2017-06-01 12:21:36'),
(36, 10000, '1111133', 'cancelled', '2017-06-01 12:21:36'),
(37, 10000, '1111133', 'cancelled', '2017-06-01 12:21:36'),
(38, 10000, '1111138', 'booked', '2017-06-07 04:24:03'),
(39, 10000, '1111141', 'booked', '2017-06-07 04:47:57');

-- --------------------------------------------------------

--
-- Table structure for table `route`
--

CREATE TABLE IF NOT EXISTS `route` (
  `rid` int(11) NOT NULL,
  `bid` varchar(11) DEFAULT NULL,
  `fromLoc` varchar(10) DEFAULT NULL,
  `toLoc` varchar(10) DEFAULT NULL,
  `fare` double DEFAULT NULL,
  `dep_date` date NOT NULL,
  `dep_time` time DEFAULT NULL,
  `arr_time` time DEFAULT NULL,
  `arr_date` date NOT NULL,
  `avalseats` int(10) NOT NULL DEFAULT '40',
  `maxseats` int(10) NOT NULL DEFAULT '40'
) ENGINE=InnoDB AUTO_INCREMENT=10009 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `route`
--

INSERT INTO `route` (`rid`, `bid`, `fromLoc`, `toLoc`, `fare`, `dep_date`, `dep_time`, `arr_time`, `arr_date`, `avalseats`, `maxseats`) VALUES
(10000, 'BB001', 'Nairobi', 'Mombasa', 1000, '2017-06-11', '20:00:00', '22:00:00', '2017-06-12', 35, 40),
(10001, 'BB001', 'Kisumu', 'Garrissa', 1100, '2017-06-21', '21:00:00', '23:00:00', '2017-05-22', 35, 40),
(10002, 'BB003', 'Nairobi', 'Laikipia', 1000, '2017-06-14', '04:13:31', '09:39:29', '2017-06-17', 40, 40),
(10003, 'BB004', 'Mombasa', 'Kisumu', 1000, '2017-06-17', '04:13:31', '09:39:29', '2017-06-22', 40, 40),
(10004, 'BB005', 'Kisumu', 'Eldoret', 500, '2017-06-17', '10:31:24', '06:18:20', '2017-06-11', 40, 40),
(10005, 'BB006', 'Eldoret', 'Turkana', 1000, '2017-06-14', '07:17:19', '09:27:29', '2017-06-16', 40, 40),
(10006, 'BB006', 'Turkana', 'Garrissa', 1000, '2017-06-14', '10:19:29', '06:40:37', '2017-06-16', 40, 40),
(10007, 'BB006', 'Garrissa', 'Nakuru', 1000, '2017-06-12', '06:26:36', '07:30:34', '2017-06-16', 40, 40),
(10008, 'BB007', 'Voi', 'Marsabit', 1000, '2017-06-15', '06:23:28', '12:32:36', '2017-06-16', 40, 40);

-- --------------------------------------------------------

--
-- Table structure for table `today`
--

CREATE TABLE IF NOT EXISTS `today` (
  `tod_time` time NOT NULL,
  `tod_date` date NOT NULL,
  `one` date NOT NULL DEFAULT '0000-00-01'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `today`
--

INSERT INTO `today` (`tod_time`, `tod_date`, `one`) VALUES
('07:54:34', '2017-06-07', '0000-00-01');

-- --------------------------------------------------------

--
-- Table structure for table `useraccounts`
--

CREATE TABLE IF NOT EXISTS `useraccounts` (
  `ACCOUNT_ID` int(11) NOT NULL,
  `ACCOUNT_NAME` varchar(255) NOT NULL,
  `ACCOUNT_USERNAME` varchar(255) NOT NULL,
  `ACCOUNT_PASSWORD` text NOT NULL,
  `ACCOUNT_TYPE` varchar(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `useraccounts`
--

INSERT INTO `useraccounts` (`ACCOUNT_ID`, `ACCOUNT_NAME`, `ACCOUNT_USERNAME`, `ACCOUNT_PASSWORD`, `ACCOUNT_TYPE`) VALUES
(3, 'Joken Villanueva', 'joken@yahoo.com', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', 'Administrator'),
(4, 'Hatch Villanueva', 'hatchvillanueva16@gmail.com', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', 'Registrar'),
(5, 'Wait', 'wait@gmail.com', 'daaad336276d15594d0e765f96c17cd746bf4971', 'Encoder'),
(6, 'gibson', 'gibson@gmail.com', '46ac8338e68f5db86c47c36d40ca48750e452caa', 'Administrator'),
(7, 'w', 'sasa@gmail.com', '7bf1ab1b8f7331ab5dc410e01f959d958bfd210e', 'Administrator'),
(8, 'ssss', 'ss', 'c455582f41f589213a7d34ccb3954c67476077da', 'Administrator'),
(9, 'Kevo', 'kevo@gmail.com', '31f650426844d11010c7b72dde7ad702b697a038', 'Administrator'),
(10, 'dd', 'ddd', '9c969ddf454079e3d439973bbab63ea6233e4087', 'Administrator');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bus`
--
ALTER TABLE `bus`
  ADD PRIMARY KEY (`bid`);

--
-- Indexes for table `card`
--
ALTER TABLE `card`
  ADD PRIMARY KEY (`num`);

--
-- Indexes for table `nb`
--
ALTER TABLE `nb`
  ADD PRIMARY KEY (`uname`);

--
-- Indexes for table `passenger`
--
ALTER TABLE `passenger`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `reserves`
--
ALTER TABLE `reserves`
  ADD PRIMARY KEY (`pnr`),
  ADD KEY `rid` (`rid`),
  ADD KEY `pid` (`pid`);

--
-- Indexes for table `route`
--
ALTER TABLE `route`
  ADD PRIMARY KEY (`rid`,`dep_date`),
  ADD KEY `bid` (`bid`);

--
-- Indexes for table `today`
--
ALTER TABLE `today`
  ADD PRIMARY KEY (`tod_time`);

--
-- Indexes for table `useraccounts`
--
ALTER TABLE `useraccounts`
  ADD PRIMARY KEY (`ACCOUNT_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `reserves`
--
ALTER TABLE `reserves`
  MODIFY `pnr` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=40;
--
-- AUTO_INCREMENT for table `route`
--
ALTER TABLE `route`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10009;
--
-- AUTO_INCREMENT for table `useraccounts`
--
ALTER TABLE `useraccounts`
  MODIFY `ACCOUNT_ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `reserves`
--
ALTER TABLE `reserves`
  ADD CONSTRAINT `reserves_ibfk_1` FOREIGN KEY (`rid`) REFERENCES `route` (`rid`),
  ADD CONSTRAINT `reserves_ibfk_2` FOREIGN KEY (`pid`) REFERENCES `passenger` (`pid`);

--
-- Constraints for table `route`
--
ALTER TABLE `route`
  ADD CONSTRAINT `route_ibfk_1` FOREIGN KEY (`bid`) REFERENCES `bus` (`bid`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
