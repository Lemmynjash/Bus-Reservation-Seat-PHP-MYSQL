<?php 


echo"<form action='pay.php' method='post'>
<div class='transbox'>
<font face='Script MT' font size='4' color='black'>&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160&#160;&#160;&#160;&#160Select Bank&#160;:&#160;&#160;&#160;&#160;&#160;</font>
<select name='no_of_tickets' >
<option value='1'>	SBI</option>
<option value='2'>	2</option>
<option value='3'>	3</option>
<option value='4'>	4</option>
<option value='5'>	5</option>
<option value='6'>	6</option>
<option value='7'>	7</option>
<option value='8'>	8</option>
<option value='9'>	9</option>


</select>

<font face='Script MT' font size='4' color='black'>&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160&#160;&#160;&#160;&#160Card Type&#160;:&#160;&#160;&#160;&#160;&#160;</font>
<select name='no_of_tickets' >
<option value='1'>	VISA</option>
<option value='2'>	Master Card</option>
<option value='3'>	3</option>
<option value='4'>	4</option>


</select>

<font face='Script MT' font size='4' color='Maroon'>&#160;&#160;&#160;&#160;Card Number:</font>
<input type='text' name='date'>
<font face='Script MT' font size='4' color='black'>&#160;&#160;&#160;&#160;Expiry Date :</font>
<input type='date' name='date'>
<br>
<br></center>
<center>
<input type='submit' value='Go'></center>
</p>
</div></f>
</form>";

?>