<html>

<head>

<title> The North Rift Shuttle Company  </title>
</head>
<body>

<center>
<form action='selseatsnext.php' method='post'>
<input type='submit'  value='go'><br><br><br>
<table border='3' style='border-color: black; cellspacing='11' cellpadding='11' ;'width =70%'>
<td>
<input type='checkbox'  name='seat[]'  value="s1">
<input type='checkbox'  name='seat[]'  value="s2">
<input type='checkbox'  name='seat[]'  value="s3">
<input type='checkbox'  name='seat[]'  value="s4">
<input type='checkbox'  name='seat[]'  value="s5">
<input type='checkbox'  name='seat[]'  value="s6">
<input type='checkbox'  name='seat[]'  value="s7">

</table>
</form>
</center>
</body>
</html>