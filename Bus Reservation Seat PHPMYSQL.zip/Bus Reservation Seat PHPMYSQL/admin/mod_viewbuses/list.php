
<div class="container">
<div class="panel panel-primary">
			<div class="panel-body">
<form  method="post" action="processreservation.php?action=delete">
	<table id="example" class="table table-striped" cellspacing="0">
<thead>
<tr>
<td>No</td>	

<td width="90"><strong>Bus Number Plate</strong></td>
 <td width="80"><strong>Bus Name</strong></td>
<td width="80"><strong>Bus Driver</strong></td>
<!--<td width="70"><strong>From</strong></td>
<td width="80"><strong>To Location</strong></td>
<td width="80"><strong>Departure Date</strong></td>
<td width="80"><strong>Departure Time</strong></td>
    <td width="80"><strong>Arrival Time</strong></td>
    <td width="80"><strong>Fare(Ksh)</strong></td>
    <td width="80"><strong>Status</strong></td>

<td width="100"><strong>Action</strong></td>-->
</tr>
</thead>
<tbody>
<?php
//$mydb->setQuery("SELECT *,roomName,firstname, lastname FROM reservation re,room ro,guest gu  WHERE re.roomNo = ro.roomNo AND re.guest_id=gu.guest_id");
/*$mydb->setQuery("SELECT * , roomName, firstname, lastname
FROM reservation re, room ro, guest gu, roomtype rt
WHERE re.roomNo = ro.roomNo
AND ro.`typeID` = rt.`typeID` 
AND re.guest_id = gu.guest_id");*/

$mydb->setQuery("SELECT *
 FROM bus ");


$cur = $mydb->loadResultList();
				  			
foreach ($cur as $result) {
?>
<tr>
<td width="5%" align="center"></td>
<!--<td>--><?php //echo $result->firstname." ".$result->lastname; ?><!--</td>-->
<td><?php echo $result->bid; ?></td>
<td><?php echo $result->bname; ?></td>
 <td><?php echo $result->busdriver; ?></td>
<!--<td><?php /*echo $result->toLoc; */?></td>-->
    <!--<td><?php /*echo $result->dep_date; */?></td>
    <td><?php /*echo $result->arr_time; */?></td>
    <td><?php /*echo $result->fare; */?></td>
    <td><?php /*echo $result->mob; */?></td>

 <td><?php /*echo $result->status; */?></td>
 <td >
	<?php /*
		if($result->status == 'booked'){ */?>

			<a href="#" class="btn btn-success btn-xs" ><i class="icon-edit">Booked</a>
		<?php
/*		}elseif($result->status == 'cancelled'){
	*/?>

			<a href=" #" class="btn btn-danger btn-xs" ><i class="icon-edit">Cancelled</a>
	<?php
/*		}else{
			*/?>

			<a href="# " class="btn btn-success btn-xs" disabled="disabled"><i class="icon-edit">Cancelled</a>
	<?php
/*		}

	*/?>
	
	
</td>-->

<?php }
?>
  
		<div class="modal fade" id="profile" tabindex="-1">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						

						<div class="alert alert-info">Profile:</div>
					</div>

					<form action="#"  method=
					"post">
						<div class="modal-body">
					
												
								<div id="display">
									
										<p>ID : <div id="infoid"></div></p><br/>
											Name : <div id="infoname"></div><br/>
											Email Address : <div id="Email"></div><br/>
											Gender : <div id="Gender"></div><br/>
											Birthday : <div id="bday"></div>
										</p>
										
								</div>
						</div>

						<div class="modal-footer">
							<button class="btn btn-default" data-dismiss="modal" type=
							"button">Close</button>
						</div>
					</form>
				</div><!-- /.modal-content -->
			</div><!-- /.modal-dialog -->
		</div><!-- /.modal -->

</table>

</form>
</div>
</div>