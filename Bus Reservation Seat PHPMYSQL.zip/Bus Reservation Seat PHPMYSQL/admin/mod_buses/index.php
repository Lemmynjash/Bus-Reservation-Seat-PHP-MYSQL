<?php
require_once("../../includes/initialize.php");
 if (!isset($_SESSION['justadmin_ID'])){
 	redirect(WEB_ROOT ."admin/login.php");
 }
$view = (isset($_GET['view']) && $_GET['view'] != '') ? $_GET['view'] : '';

switch ($view) {
	case 'add' :
		$content    = 'add.php';
		break;

	case 'list' :
		$content    = 'list.php';
		break;

	case 'edit' :
		$content    = 'edit.php';		
		break;
    case 'view' :
		$content    = 'view.php';		
		break;

	default :
		$content    = 'add.php';
}
  include '../modal.php';
require_once '../themes/backendTemplate.php';
?>


  
