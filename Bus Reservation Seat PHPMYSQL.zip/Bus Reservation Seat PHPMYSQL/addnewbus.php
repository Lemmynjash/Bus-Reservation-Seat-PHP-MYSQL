<html>

<head>

    <title>The North Rift Shuttle Company </title>
</head>
<style>

    k{


        color:green;
        font-size:20px;

        background-color:#f28858;
        height:100px;
        width:1345px;
        position:absolute;
        top:1px;

        left:0px;
        right:0px;
    }


    n{


        color:white;
        font-size:20px;

        background-color:#f28858;
        height:220px;
        width:100%;
        position:absolute;
        left:0px;
    }



    nav {



        background-color:#f28858;
        height: 40px;
        width: 1345px;
        position:absolute;
        top:97;
        right:0px;
    }

    nav ul{
        list-style-type:none;
        float:right;
    }
    nav li{
        float:left;
        margin-right:12px;
    }

    div{
        position:absolute;
        top:200px;
        right:80px;

        border:1px solid black;
        background:skyblue;
        width:400px;
        border-radius:15px;
    }





    <style>






     body
     {
         background-color:white;
     }


    pub{

        text-align:center;

        background-color: blue;

        position:absolute;
        height: 40px;
        width: 400px;
        top:145;
        left:200px;
    }



    puk{

        text-align:center;

        background-color: blue;

        position:absolute;
        height: 80px;
        width: 550px;
        top:145;
        left:200px;
    }



    pud{

        text-align:center;

        background-color: blue;

        position:absolute;
        height: 40px;
        width: 540px;
        top:145;
        left:200px;
    }


</style>


<k>

    <nav>
        <ul >
            <li class="active"><a href="adminhome.html">Home</a></li>
            <li ><a href="about.html">About us</a></li>
            <li><a href="viewallbookingsadmin.php">View All Bookings</a></li>
            <li><a href="addnewbus.php">Add New Bus</a></li>
            <li><a href="addnewadmin.html">Add New Admin</a></li>
            <li><a href="contact.html">Contact Us</a></li>
        </ul></nav>

    <imgl>
        &#160;&#160;&#160;&#160;<img src="images/my.png" />
    </imgl>
</k>






<br><br><br><br><br><br><br><br>


<form action="selectedbus.php" method="post">
    <div class="transbox">

        <center>
            <font face="Impact" font size="6" color="Maroon"><u>Fill Your Details</u></font><br>
            <br>
            <font face="Script MT" font size="4" color="black">Confirm Date :</font>
            <input type="date" name="date">
            <br>
            <br></center>
        <font face="Script MT" font size="4" color="black">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160&#160;&#160;&#160;&#160No. of Tickets&#160;:&#160;&#160;&#160;&#160;&#160;</font>
        <select name="no_of_tickets" >
            <option value="1">	1</option>
            <option value="2">	2</option>
            <option value="3">	3</option>
            <option value="4">	4</option>
            <option value="5">	5</option>
            <option value="6">	6</option>



        </select>

        <br><center>
            <br><font face="Script MT" font size="4" color="black">Name&#160;:&#160;&#160;&#160;&#160;&#160;&#160;</font>
            <input type= "text" name="name">
            <br>
            <br></center>
        <center>
            <font face="Script MT" font size="4" color="black">Email &#160;:&#160;</font>&#160;&#160;&#160;&#160;&#160;
            <input type= "email" name="email_id">
            <br>

            <br>
        </center><center>
            <font face="Script MT" font size="4" color="black">Mobile &#160;:</font>
            &#160;&#160;&#160;&#160;<input type= "number" name="mob" min="0" max= "9999999999">
            &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;<br>
            <br><br></center>
        <center>
            <font face="Script MT" font size="6" color="Maroon"><u>Select Payment Mode</u></font><br><br>
            <input type="radio" name="mode" value="1"><font face="Script MT" font size="4" color="black">Debit & Credit Card</font><br>
            <input type="radio" name="mode" value="2"><font face="Script MT" font size="4" color="black">Mpesa&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><br><br>
        </center>




        <center>
            <input type="submit" value="Book Now"></center>
        </p>
    </div></f>
</form>

<br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<n>
    <font face="Gunplay" font size="3" color="white"><h3>&#160;&#160;About The North Rift Shuttle Company</h3></font>
    <font face="Gunplay" font size="2" color="white"><p>&#160;&#160;North Rift Shuttle Booking is a registered online shuttle booking website by the Our Orange Democratic Team.  <br>&#160;&#160;Any issues can be brought up to the judicial of the Baba Jakom Raila High Court, Nairobi.  </p></font>
    <ul >
        <li><a href="about.html">	<font face="Gunplay" font size="2" color="white">About</a> </li></font>
        <li><a href="tc.html">	<font face="Gunplay" font size="2" color="white">Term of Services</a> </li></font>

    </ul>

    <font face="Gunplay" font size="2" color="white">&#160;&#160;THE NORTH RIFT SHUTTLE COMPANY COPYRIGHT � 2016-2017 ALL RIGHT RESERVED.&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;
        &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;
        &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;
        &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;
        &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;
        &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;
        &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;
        &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;
        &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;
        &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;
        &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;





    </font>
    <img2>
        <img src="soc.png" />
    </img2>

</n>

</body>
</html>