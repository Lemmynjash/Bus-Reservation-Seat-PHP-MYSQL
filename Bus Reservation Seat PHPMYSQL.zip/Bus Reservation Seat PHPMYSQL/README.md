# Online-Bus-Reservation

An Online Portal which provides users a facility to reserve seats, cancellation of seats and different types of enquiry which need an instant and quick reservation & avail a degree of comfort to both Organization & Passengers.

http://localhost/Bus/index.html
